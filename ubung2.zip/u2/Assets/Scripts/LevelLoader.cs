﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.SceneManagement;

public class LevelLoader : MonoBehaviour
{
    static Level level1, level2, level3;
    [SerializeField] public GameObject walls;
    [SerializeField] public GameObject floors;
    [SerializeField] public GameObject player;
    GameObject c_w;
    GameObject c_f;
    GameObject c_p;
    public int current_l = 1;
    public Level[] l;
    public int i = 0;



    public struct Level
    {
        public string[] walls;
        public string[] floors;
        public string player;

        public Level(string[] walls, string[] floors, string player)
        {
            this.walls = walls;
            this.floors = floors;
            this.player = player;
        }
    }


    public struct ObjectData
    {
        public Vector3 position;
        public Vector3 scale;
        public ObjectData(Vector3 position, Vector3 scale)
        {
            this.position = position;
            this.scale = scale;
        }
    }


    private void Awake()
    {
        init_level();
        l = new Level[] { level1, level2, level3 };

    }
    private void Start()
    {
        InitiateGame(level1, 1);
    }

    private void Update()
    {
        //dont know how to switch level...
    }

    public void high_level() {
        foreach (GameObject g in FindObjectsOfType<GameObject>()) {
            if (g.name.Equals("Wall(Clone)") || g.name.Equals("Floor(Clone)") || g.name.Equals("Player2D(Clone)")) {
                Destroy(g.gameObject);
            }
        }
        if (current_l <= 2)
        {
            current_l++;
            InitiateGame(l[current_l - 1], current_l);
        }
        else {
            Debug.Log("You have passed all levels");
            SceneManager.LoadScene("Startmenue");
        }
    }

    //第一关4+1+1
    //第二关8+2+1
    //第三关16+4+1
    private void InitiateGame(Level obj, int a)
    {
        Debug.Log("???");
        ObjectData[] od = read_level(obj);
        for (int i = 0; i < (int)(od.Length - 1 - Mathf.Pow( 2, a - 1)); i++)
        {
            c_w = Instantiate(walls, od[i].position, Quaternion.identity);
            c_w.transform.localScale = od[i].scale;
        }
        for (int i = (int)(od.Length - 1 - Mathf.Pow(2, a - 1)); i < od.Length - 1; i++)
        {
            c_f = Instantiate(floors, od[i].position, Quaternion.identity);
            c_f.transform.localScale = od[i].scale;
        }
        c_p = Instantiate(player, od[od.Length - 1].position, Quaternion.identity);
        c_p.transform.localScale = od[od.Length - 1].scale;
    }

    public void init_level()
    {
        string Jsonpath = Application.streamingAssetsPath;
        StreamReader sr = new StreamReader(Jsonpath + "/Level01.json");
        string json = sr.ReadToEnd();
        level1 = JsonUtility.FromJson<Level>(json);
        sr = new StreamReader(Jsonpath + "/Level02.json");
        json = sr.ReadToEnd();
        level2 = JsonUtility.FromJson<Level>(json);
        sr = new StreamReader(Jsonpath + "/Level03.json");
        json = sr.ReadToEnd();
        level3 = JsonUtility.FromJson<Level>(json);

    }


    public ObjectData[] read_level(Level level)
    {
        int length = level.walls.Length + level.floors.Length + 1;
        ObjectData[] od = new ObjectData[length];
        int i = 0;
        for (i = 0; i < level.walls.Length; i++)
        {
            od[i] = JsonUtility.FromJson<ObjectData>(level.walls[i]);
        }
        for (i = level.walls.Length; i < level.walls.Length + level.floors.Length; i++)
        {
            od[i] = JsonUtility.FromJson<ObjectData>(level.floors[i - level.walls.Length]);
        }
        od[i] = JsonUtility.FromJson<ObjectData>(level.player);
        return od;
    }
}
