﻿using UnityEngine;

//This class will spawn a new coin each time the old one is destroyed
public class CoinSpawner : MonoBehaviour
{

    [SerializeField] Transform floor; //to drag the floor cube into. The transform will be taken automatically
    [SerializeField] Coin coin; //the prefab with coin script attached to it
    Coin spawnedCoin; // private variable to hold track of current spawned coin
    public Operation operation{get; private set;}
    public static int score;
    void Start()
    {
        this.Respawn(); //spawn new Coin
    }

    //when a coin gets hit, it has to call this method
    public void CoinHit(Coin coin){
        if(coin.correspondingNumber == this.operation.Result()){
            score++;
            this.Respawn(); //if it was the correct coin => Respawn
        }else{
            if (score > 0) {
                score--;
            }
            //Do nothing if its the wrong coin
        }
    }

    void Respawn(){
        foreach(Coin coin in FindObjectsOfType<Coin>()){
            Destroy(coin.gameObject); //Destroy all remaining coins on the field;
        }

        if(Random.Range(0f, 1f) > .5f){ //Decide wich operation should be generated
            this.operation = new Sum(Random.Range(0, 50), Random.Range(0, 50));
        }else{
            this.operation = new Substract(Random.Range(0,50), Random.Range(0, 50));
        }

        this.Spawn(this.operation.Result()); //spawn the correct coin
        for(int i = 0; i < 3; i++){ //spawn 3 maybe false coins (no check for doubled correct coins here)
            this.Spawn(Random.Range(-50, 100));
        }

        
    }
    void Spawn(int correspondingNumber){
        float x = Random.Range(this.floor.position.x - this.floor.lossyScale.x/2,
                                this.floor.position.x + this.floor.lossyScale.x/2); //get range of floor to spawn new coin

        float y = Random.Range(this.floor.position.y - this.floor.lossyScale.y/2,
                                this.floor.position.y + this.floor.lossyScale.y/2);

        this.spawnedCoin = Instantiate(this.coin, new Vector2(x, y), Quaternion.identity).Init(correspondingNumber, this); //actually spawn a new coin
    }
}
